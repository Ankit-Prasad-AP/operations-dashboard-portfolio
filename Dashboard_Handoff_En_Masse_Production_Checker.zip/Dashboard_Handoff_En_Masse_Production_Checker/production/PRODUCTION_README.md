# Production README

Production file: `APS_EnMasse_Production_Checker_v13.html`

This is the latest production dashboard preserved in this handoff package. No production logic changes were made for this aesthetic portfolio refresh.

Expected production inputs include the current-week schedule, optional prior-week schedule, and Daily Production Report. The production tool supports current/prior week context, production history review, case math, finished rows, undo/redo, and case-only XLSM export.

Verification performed in this handoff: file existence and package inclusion. Production browser behavior was not re-tested during the aesthetic portfolio refresh.

WARNING: DO NOT UPLOAD PRODUCTION FILES TO THE PUBLIC GITHUB REPOSITORY. Production files may contain operational terminology or business workflow details intended only for private use.
