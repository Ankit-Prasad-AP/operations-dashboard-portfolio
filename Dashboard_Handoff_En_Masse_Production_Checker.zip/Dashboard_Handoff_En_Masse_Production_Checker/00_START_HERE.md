# 00 START HERE

## Project

Project name: En Masse Production Checker

Production dashboard: A private production workflow that compares scheduled items to production history, supports case edits, finished rows, and case-only schedule update exports.

Recruiter-facing GitHub demo: A polished, sanitized decision cockpit showing schedule review, production-history matching, KPI cards, visual analytics, item drilldowns, case-reduction decisions, and demo CSV export.

Current build/date: aesthetic portfolio refresh created 2026-08-24. Production version preserved as v13.

## What is inside this ZIP

- `00_START_HERE.md`: This file. Start here.
- `01_BUILD_SUMMARY.md`: What changed and what was tested.
- `02_HOSTING_INSTRUCTIONS.md`: GitHub web and GitHub Desktop hosting steps.
- `03_FILE_MANIFEST.md`: Upload safety guide for every file.
- `04_VERIFICATION_NOTES.md`: Actual checks performed and remaining manual checks.
- `production/`: Private production dashboard. Do not upload to public GitHub.
- `git_portfolio/`: Contains the sanitized repo-ready GitHub dashboard ZIP.
- `verification/`: Contains `VERIFY_BEFORE_PUSH.md`, which stays outside the repo.

## What I should do next

1. Review the build summary.
2. Open/test the GitHub demo locally.
3. Run the verification file outside the repo.
4. Extract the repo-ready dashboard folder.
5. Place it under `operations-dashboard-portfolio/dashboards/`.
6. Add the landing-page card/snippet.
7. Commit and push.
8. Verify GitHub Pages URL.

## GitHub destination

Your portfolio repository structure is:

```text
operations-dashboard-portfolio/
├── index.html
├── README.md
└── dashboards/
    └── <dashboard-slug>/
```

The repo-ready dashboard folder belongs under:

`operations-dashboard-portfolio/dashboards/`

## Hosting assistance instruction

If this ZIP is uploaded to another AI assistant, first read `00_START_HERE.md`, then inspect `git_portfolio/GIT_Dashboard_En_Masse_Production_Checker.zip`, then help the user verify the package, place the dashboard in the existing `operations-dashboard-portfolio` repository, update the root landing page using `LANDING_PAGE_ENTRY.md`, and enable/test GitHub Pages. Do not upload or publish anything without the user's explicit approval.
