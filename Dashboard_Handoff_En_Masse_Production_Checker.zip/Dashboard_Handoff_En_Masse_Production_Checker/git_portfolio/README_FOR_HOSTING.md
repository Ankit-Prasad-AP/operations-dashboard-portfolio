# README FOR HOSTING

Dashboard slug: `en-masse-production-checker`

Copy this repo-ready folder into:

`operations-dashboard-portfolio/dashboards/en-masse-production-checker/`

Expected public URL after GitHub Pages deploys:

`https://ankit-prasad-ap.github.io/operations-dashboard-portfolio/dashboards/en-masse-production-checker/`

Inside the inner ZIP, the landing-page snippet is located at:

`en-masse-production-checker/LANDING_PAGE_ENTRY.md`

Do not copy `verification/VERIFY_BEFORE_PUSH.md` into the public GitHub repository.

Do not copy production files into the public GitHub repository. The production dashboard remains only in the outer handoff package for private use.
