# VERIFY BEFORE PUSH

Run this outside the repo-ready dashboard folder. Do not copy this file into GitHub.

## 1. Confirm folder placement

Expected public repo location:

`operations-dashboard-portfolio/dashboards/en-masse-production-checker/`

## 2. Confirm production files are not staged

Check that no files from `production/` are inside the public repo.

## 3. Search for real identifiers

Replace placeholders below with real private terms on your machine before running.

```bash
grep -Rni "<REAL_EMPLOYER_NAME>\|<REAL_CUSTOMER_NAME>\|<REAL_SUPPLIER_NAME>\|<REAL_ITEM_CODE_PATTERN>" dashboards/en-masse-production-checker || true
```

Expected result: no matches.

## 4. Confirm demo data is synthetic

Open:

`dashboards/en-masse-production-checker/sample_data/demo_data.json`

Confirm all items, lots, lines, schedules, dates, and quantities are synthetic.

## 5. Browser test

Open `dashboards/en-masse-production-checker/index.html` locally. Test:

- Load Demo Data
- Search
- Show prior week
- Action view
- Schedule filter
- Item modal
- Select production entries
- Reduce current-week cases
- Finished checkbox
- Export Demo CSV

## 6. GitHub Pages test

After push, verify:

`https://ankit-prasad-ap.github.io/operations-dashboard-portfolio/dashboards/en-masse-production-checker/`
