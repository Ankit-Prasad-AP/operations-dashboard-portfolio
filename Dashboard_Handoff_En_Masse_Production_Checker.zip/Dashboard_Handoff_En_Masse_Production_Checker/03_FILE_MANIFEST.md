# File Manifest

| File or folder | Purpose | Safe to upload to GitHub? | Keep outside repository? | Production-only? | Portfolio-only? |
|---|---|---:|---:|---:|---:|
| `00_START_HERE.md` | Handoff guide for another AI assistant | No | Yes | No | No |
| `01_BUILD_SUMMARY.md` | Build notes and test summary | No | Yes | No | No |
| `02_HOSTING_INSTRUCTIONS.md` | Hosting instructions for existing GitHub setup | No | Yes | No | No |
| `03_FILE_MANIFEST.md` | Upload safety map | No | Yes | No | No |
| `04_VERIFICATION_NOTES.md` | Checks performed and remaining verification | No | Yes | No | No |
| `production/APS_EnMasse_Production_Checker_v13.html` | Private production dashboard | No | Yes | Yes | No |
| `production/PRODUCTION_README.md` | Production warning and input notes | No | Yes | Yes | No |
| `git_portfolio/GIT_Dashboard_En_Masse_Production_Checker.zip` | Repo-ready public demo package | Yes, after extracting only the repo folder | No | No | Yes |
| `git_portfolio/README_FOR_HOSTING.md` | Explains what to copy and where | No | Yes | No | No |
| `verification/VERIFY_BEFORE_PUSH.md` | Local verification checklist | No | Yes | No | No |
| `en-masse-production-checker/index.html` inside inner ZIP | Public dashboard page | Yes | No | No | Yes |
| `en-masse-production-checker/assets/*` inside inner ZIP | Public demo JavaScript and config | Yes | No | No | Yes |
| `en-masse-production-checker/sample_data/demo_data.json` inside inner ZIP | Synthetic demo data | Yes | No | No | Yes |
| `en-masse-production-checker/LANDING_PAGE_ENTRY.md` inside inner ZIP | Root landing page card snippet | Use content in root `index.html`; do not need to keep file public | No | No | Yes |
| `en-masse-production-checker/.gitignore` inside inner ZIP | Prevents real data upload | Yes | No | No | Yes |
