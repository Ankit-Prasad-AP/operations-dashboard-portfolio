# Hosting Instructions

GitHub account: `Ankit-Prasad-AP`
Repository: `operations-dashboard-portfolio`
GitHub Pages source: `main` branch, `/ (root)`
Dashboard destination folder: `dashboards/en-masse-production-checker/`
Expected public URL after deployment:

`https://ankit-prasad-ap.github.io/operations-dashboard-portfolio/dashboards/en-masse-production-checker/`

Do not assume the site is live until you open and verify the URL.

## Method A — GitHub website

1. Download and unzip `Dashboard_Handoff_En_Masse_Production_Checker.zip` locally.
2. Open `git_portfolio/GIT_Dashboard_En_Masse_Production_Checker.zip`.
3. Extract the folder `en-masse-production-checker`.
4. Go to GitHub → `Ankit-Prasad-AP/operations-dashboard-portfolio`.
5. Open the `dashboards/` folder.
6. Upload the extracted `en-masse-production-checker` folder contents into `dashboards/en-masse-production-checker/`.
7. Open `en-masse-production-checker/LANDING_PAGE_ENTRY.md` locally.
8. Copy the landing-page card snippet into the root `index.html` where dashboard cards are listed.
9. Commit the changes.
10. Wait for GitHub Pages deployment.
11. Open the expected public URL and test the demo.

## Method B — GitHub Desktop

1. Open GitHub Desktop.
2. Clone or open `Ankit-Prasad-AP/operations-dashboard-portfolio`.
3. Extract `git_portfolio/GIT_Dashboard_En_Masse_Production_Checker.zip`.
4. Copy the extracted `en-masse-production-checker` folder into `operations-dashboard-portfolio/dashboards/`.
5. Open `en-masse-production-checker/LANDING_PAGE_ENTRY.md`.
6. Copy the snippet into the root `index.html`.
7. Review changed files in GitHub Desktop.
8. Confirm production files and verification files are not staged inside the public repo.
9. Commit with a message such as `Add production update decision cockpit demo`.
10. Push to `main`.
11. Wait for Pages deployment and verify the public URL.
